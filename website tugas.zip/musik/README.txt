CARA MENGGUNAKAN FITUR MUSIK

1. Download file musik dalam format .mp3
2. Letakkan file musik di folder ini dengan nama:
   - gitar.mp3 (untuk M.hafizul Fahmi)
   - basket.mp3 (untuk Risky Aditya) 
   - mancing.mp3 (untuk Ahmad Saufi Ridhoni)

3. File musik bisa di-download dari:
   - Situs musik gratis seperti pixabay.com atau freesound.org
   - Atau gunakan file musik Anda sendiri

4. Ukuran file disarankan maksimal 2MB untuk loading yang cepat

5. Format yang didukung: .mp3, .wav, .ogg
